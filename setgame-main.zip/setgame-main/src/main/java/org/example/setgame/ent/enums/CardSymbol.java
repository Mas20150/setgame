package org.example.setgame.ent.enums;

public enum CardSymbol {
    diamond,
    squiggle,
    oval
}
