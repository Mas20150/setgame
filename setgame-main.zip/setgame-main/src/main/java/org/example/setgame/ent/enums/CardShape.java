package org.example.setgame.ent.enums;

public enum CardShape {
        solid,
        striped,
        outlined
}
