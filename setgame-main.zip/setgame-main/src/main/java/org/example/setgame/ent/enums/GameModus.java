package org.example.setgame.ent.enums;

public enum GameModus {
    SHORT,
    LONG
}
