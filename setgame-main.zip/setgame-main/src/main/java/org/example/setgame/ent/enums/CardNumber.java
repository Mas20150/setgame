package org.example.setgame.ent.enums;

public enum CardNumber {
    one,
    two,
    three
}
