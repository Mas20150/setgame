package org.example.setgame.ent.enums;

public enum CardColor {
    red,
    green,
    purple
}
