Das Programm nutzt Hibernate, die Zugangsdaten stehen in der conf Datei.
Die Datenbank ist über das Hochschulnetz erreichbar. Ein SQL Script der Datenbank liegt ebenfalls bei.